  * Java HttpURLConnection
  * [Apache Commons HTTP 4.x](ApacheCommonsHttp4.md)
  * [Jetty HTTP Client v6.x](JettyHttp6.md)
